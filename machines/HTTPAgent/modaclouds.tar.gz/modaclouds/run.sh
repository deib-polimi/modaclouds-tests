#!/bin/sh

IMAGE="$1"
VERSION="$2"

sudo docker run -d -P --name=$IMAGE$VERSION $IMAGE$VERSION
sudo docker ps
