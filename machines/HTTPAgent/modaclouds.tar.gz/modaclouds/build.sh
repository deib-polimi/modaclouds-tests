#!/bin/sh

IMAGE="$1"
VERSION="$2"

sudo docker build -f $IMAGE.docker -t $IMAGE$VERSION .
