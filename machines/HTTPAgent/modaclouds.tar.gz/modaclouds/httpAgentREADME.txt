In order to install and run the HTTP agent, just create a new Amazon Linux VM and perform the following commands.

1. chmod +x *.sh
2. sudo ./httpAgentInstall.sh
3. sudo ./httpAgentRun.sh 
