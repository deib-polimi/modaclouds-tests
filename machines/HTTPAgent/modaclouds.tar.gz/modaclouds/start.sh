#!/bin/sh

MIRROR="$1"
MASTER="$2"

# TODO: extend to support n mirrors

sudo docker rm -f mirror master

sudo docker run -d -P --name=mirror mirror$MIRROR
sudo docker run -d -P --name=master --link mirror:mirror master$MASTER

