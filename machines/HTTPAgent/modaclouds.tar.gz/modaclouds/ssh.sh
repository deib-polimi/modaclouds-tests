#!/bin/sh

PORT="$1"

ssh root@localhost -o StrictHostKeyChecking=no -p $PORT -i id_rsa 
