#!/bin/sh

wget -qO- https://get.docker.com/ | sh
service docker start
./build.sh httpagent 16

