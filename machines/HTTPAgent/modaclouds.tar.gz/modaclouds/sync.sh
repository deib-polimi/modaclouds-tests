#!/bin/sh

MIRROR="$1"
SYNCDIR=`cat ./SYNCDIR`
TARGETDIR=`cat ./TARGETDIR`
rsync -cvr -e "ssh -o StrictHostKeyChecking=no" --chmod=0755  $SYNCDIR root@$MIRROR:$TARGETDIR
